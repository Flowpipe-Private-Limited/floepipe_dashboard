import React, { useEffect, useState, useRef } from "react";
import { FileCheck, Layers, ChevronRight } from "lucide-react";
import "./Products.css";
import { IoMdArrowDropdown } from "react-icons/io";
import { ApirequestHandler } from "../../utils/Apis/apiRequestHandler";
import {
  ClientService,
  getAllCategoriesService,
  getServicesByCategoryService,
  SubscribeService,
} from "../../utils/Apis/api";

const Products = () => {
  const [filter, setFilter] = useState("All Products");
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [products, setProducts] = useState([]);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const scrollContainerRef = useRef(null);

    const fetchCategories = async () => {
      console.group("FETCH CATEGORIES");

      await ApirequestHandler(
        () => getAllCategoriesService(),
        null,
        (res) => {
          console.log("Category API Response:", res);

          if (res?.success && Array.isArray(res.data)) {
            const mapped = res.data.map((cat) => ({
              categoryId: cat.categoryId,
              categoryName: cat.categoryName,
            }));

            console.table(mapped);
            setCategories(mapped);
          }
        },
        (err) => console.error("Category Error:", err)
      );

      console.groupEnd();
    };

  useEffect(() => {
    fetchCategories();
  }, []);

  const fetchClientServices = async (currentProducts) => {
    console.group("FETCH CLIENT SERVICES");

    const clientId = localStorage.getItem("clientId");
    if (!clientId || currentProducts.length === 0) {
      console.warn("ClientId missing or no products");
      console.groupEnd();
      return;
    }

    await ApirequestHandler(
      () => ClientService(clientId),
      null,
      (res) => {
        console.log("Client Services Response:", res);

        if (res?.success && Array.isArray(res.data)) {
          const updated = currentProducts.map((p) => {
            const found = res.data.find(
              (s) => s.serviceId === p.serviceId
            );
            return found ? { ...p, status: found.status } : p;
          });

          console.table(updated);
          setProducts(updated);
        }
      },
      (err) => console.error("Client Service Error:", err)
    );

    console.groupEnd();
  };

  const fetchServicesByCategory = async (categoryId) => {
    console.group("FETCH SERVICES BY CATEGORY");
    console.log("Selected Category:", categoryId);

    await ApirequestHandler(
      () => getServicesByCategoryService(categoryId),
      null,
      (res) => {
        console.log("Service Config Response:", res);

        if (res?.success && Array.isArray(res.data)) {
          const mappedProducts = res.data.map((item) => ({
            id: item._id,
            serviceId: item.serviceId,
            title: item.serviceName,
            description: `${item.serviceName} verification service`,
            credits: item.rateLimit || 0,
            status: "Subscribe",
            icon: <FileCheck size={22} />,
            iconColor: "purple",
          }));

          console.table(mappedProducts);
          setProducts(mappedProducts);
          fetchClientServices(mappedProducts);
        } else {
          console.warn("No services found");
          setProducts([]);
        }
      },
      (err) => console.error("Service Config Error:", err)
    );

    console.groupEnd();
  };

  /* ---------------- CATEGORY CLICK ---------------- */
  const handleCategorySelect = (categoryId) => {
    console.log("Category Clicked:", categoryId);
    setSelectedCategory(categoryId);
    fetchServicesByCategory(categoryId);
  };

  /* ---------------- SUBSCRIBE ---------------- */
  const handleSubscribe = async (serviceId) => {
    console.group("SUBSCRIBE SERVICE");

    const clientId = localStorage.getItem("clientId");
    if (!clientId) {
      console.error("ClientId missing");
      console.groupEnd();
      return;
    }

    const payload = { clientId, serviceId, status: "Pending" };
    console.log("Subscribe Payload:", payload);

    const res = await SubscribeService(payload);
    console.log("Subscribe Response:", res);

    if (res?.data?.success) {
      setProducts((prev) =>
        prev.map((p) =>
          p.serviceId === serviceId ? { ...p, status: "Pending" } : p
        )
      );
    }

    console.groupEnd();
  };

  /* ---------------- FILTER ---------------- */
  const filteredProducts =
    filter === "All Products"
      ? products
      : products.filter((product) => {
          if (filter === "Subscribed") return product.status === "Subscribed";
          if (filter === "Pendding Approvals") return product.status === "Pending";
          if (filter === "Subscribe")
            return !product.status || product.status === "Subscribe";
          return true;
        });

  /* ---------------- UI ---------------- */
  return (
    <div className="products-container">
      {/* CATEGORY SLIDER */}
      <div className="category-slider-section">
        <div className="category-scroll-wrapper" ref={scrollContainerRef}>
          {categories.map((cat) => (
            <div
              key={cat.categoryId}
              className={`category-item ${
                selectedCategory === cat.categoryId ? "active" : ""
              }`}
              onClick={() => handleCategorySelect(cat.categoryId)}
            >
              {cat.categoryName}
            </div>
          ))}
        </div>

        <button
          className="scroll-arrow-btn"
          onClick={() =>
            scrollContainerRef.current.scrollBy({ left: 200 })
          }
        >
          <ChevronRight size={20} />
        </button>
      </div>

      {/* PRODUCTS GRID */}
      <div className="products-grid">
        {filteredProducts.map((product) => (
          <div key={product.id} className="product-card">
            <div className="product-info">
              <div className="icon-container purple">
                {product.icon}
              </div>

              <div>
                <h4 className="product-title-text">{product.title}</h4>
                <p className="product-desc">{product.description}</p>
              </div>
            </div>

            <div className="card-footer">
            
              <div className="credits-info">
                <Layers size={14} /> Available credits : {product.credits}
              </div>

              <button
                className={`action-btn ${
                  product.status === "Pending"
                    ? "pending"
                    : product.status === "Subscribed"
                    ? "subscribed"
                    : "unsubscribed"
                }`}
                disabled={
                  product.status === "Pending" ||
                  product.status === "Subscribed"
                }
                onClick={() => handleSubscribe(product.serviceId)}
              >
                {product.status === "Pending"
                  ? "Pending"
                  : product.status === "Subscribed"
                  ? "Subscribed"
                  : "Subscribe"}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Products;
